# BayesWait paper source, v15

The main LaTeX file is main.tex. To compile locally with TeX Live or MacTeX, run the following command in the extracted directory.

    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

To compile in Overleaf, upload the ZIP as a new project and select main.tex as the main document with pdfLaTeX as the compiler.

The source includes the manuscript, the TikZ framework figure, all three tables, and the BibTeX bibliography. The table values are included directly in the LaTeX files, so building the paper requires no experiment replay or external data files.
